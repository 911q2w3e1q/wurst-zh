/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.gametest;

import static net.wurstclient.gametest.WurstClientTestHelper.*;

import java.util.List;

import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.MixinEnvironment;

import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.TestInput;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestClientWorldContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestServerContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.fabricmc.fabric.api.client.gametest.v1.world.TestWorldBuilder;
import net.fabricmc.fabric.impl.client.gametest.TestSystemProperties;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.SharedConstants;
import net.minecraft.client.gui.screens.worldselection.WorldCreationUiState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.level.levelgen.FlatLevelSource;
import net.minecraft.world.level.levelgen.flat.FlatLayerInfo;
import net.minecraft.world.level.levelgen.flat.FlatLevelGeneratorSettings;
import net.wurstclient.gametest.tests.*;
import net.wurstclient.gametest.tests.filters.FilterBabiesTest;
import net.wurstclient.gametest.tests.filters.FilterPassiveWaterTest;
import net.wurstclient.gametest.tests.filters.FilterPetsTest;

public class WurstTest implements FabricClientGameTest
{
	public static final Logger LOGGER = LoggerFactory.getLogger("Wurst Test");
	
	public static final boolean IS_SODIUM_INSTALLED =
		FabricLoader.getInstance().isModLoaded("sodium");
	public static final boolean IS_LOOTR_INSTALLED =
		FabricLoader.getInstance().isModLoaded("lootr");
	
	@Override
	public void runTest(ClientGameTestContext context)
	{
		if(!TestSystemProperties.DISABLE_NETWORK_SYNCHRONIZER)
			throw new RuntimeException("Network synchronizer is not disabled");
		
		LOGGER.info("Starting Wurst Client GameTest");
		hideSplashTexts(context);
		waitForTitleScreenFade(context);
		
		LOGGER.info("Reached title screen");
		assertScreenshotEquals(context, "title_screen",
			"https://i.imgur.com/xSAHDXr.png");
		
		AltManagerTest.testAltManagerButton(context);
		
		LOGGER.info("Creating test world");
		TestWorldBuilder worldBuilder = context.worldBuilder();
		worldBuilder.adjustSettings(creator -> {
			String mcVersion = SharedConstants.getCurrentVersion().name();
			creator.setName("E2E Test " + mcVersion);
			creator.setGameMode(WorldCreationUiState.SelectedGameMode.CREATIVE);
			creator.getGameRules().set(GameRules.SEND_COMMAND_FEEDBACK, false,
				null);
			applyFlatPresetWithSmoothStone(creator);
		});
		
		try(TestSingleplayerContext spContext = worldBuilder.create())
		{
			testInWorld(context, spContext);
			LOGGER.info("Exiting test world");
		}
		
		LOGGER.info("Test complete");
	}
	
	private void testInWorld(ClientGameTestContext context,
		TestSingleplayerContext spContext)
	{
		TestInput input = context.getInput();
		TestClientWorldContext world = spContext.getClientWorld();
		TestServerContext server = spContext.getServer();
		
		// Disable chunk fade
		context.runOnClient(mc -> mc.options.chunkSectionFadeInTime().set(0.0));
		
		runCommand(server, "time set noon");
		runCommand(server, "tp 0 -57 0");
		BlockTestHelper.setBlocksAndWait(context, spContext, blocks -> {
			blocks.fill(0, -60, 0, 0, -58, 0, Blocks.SMOOTH_STONE);
			blocks.fill(-12, -60, 10, 12, -48, 10, Blocks.SMOOTH_STONE);
		});
		
		LOGGER.info("Loading chunks");
		context.waitTicks(2);
		world.waitForChunksRender();
		
		assertScreenshotEquals(context, "in_game",
			"https://i.imgur.com/EfzN9Cd.png");
		
		LOGGER.info("Recording debug menu");
		input.pressKey(GLFW.GLFW_KEY_F3);
		context.takeScreenshot("debug_menu");
		input.pressKey(GLFW.GLFW_KEY_F3);
		
		LOGGER.info("Checking for broken mixins");
		MixinEnvironment.getCurrentEnvironment().audit();
		
		LOGGER.info("Opening inventory");
		input.pressKey(GLFW.GLFW_KEY_E);
		assertScreenshotEquals(context, "inventory",
			"https://i.imgur.com/LyQ5FSD.png");
		input.pressKey(GLFW.GLFW_KEY_ESCAPE);
		
		runWurstCommand(context,
			"setmode WurstLogo visibility only_when_outdated");
		runWurstCommand(context, "setcheckbox HackList animations off");
		
		new InGameMenuTest(context, spContext).run();
		
		// Test entity filters
		new FilterBabiesTest(context, spContext).run();
		new FilterPassiveWaterTest(context, spContext).run();
		new FilterPetsTest(context, spContext).run();
		
		// TODO: Open ClickGUI and Navigator
		
		// Test Wurst hacks
		new AutoSprintHackTest(context, spContext).run();
		new AutoMineHackTest(context, spContext).run();
		new BlinkHackSmokeTest(context, spContext).run();
		new ChestEspGroupTest(context, spContext).run();
		new ChestEspRenderingTest(context, spContext).run();
		new FreecamHackTest(context, spContext).run();
		new LsdHackTest(context, spContext).run();
		new NoFallHackTest(context, spContext).run();
		new NoShieldOverlayHackTest(context, spContext).run();
		new NoWeatherHackTest(context, spContext).run();
		new XRayHackTest(context, spContext).run();
		
		// Test Wurst commands
		new CopyItemCmdTest(context, spContext).run();
		new GiveCmdTest(context, spContext).run();
		new ModifyCmdTest(context, spContext).run();
		
		// TODO: Test more Wurst features
		
		// Test special cases
		new AttributeSwapMechanicTest(context, spContext).run();
		new OcclusionCullingTest(context, spContext).run();
		new PistonTest(context, spContext).run();
	}
	
	// because the grass texture is randomized and smooth stone isn't
	private void applyFlatPresetWithSmoothStone(WorldCreationUiState creator)
	{
		FlatLevelGeneratorSettings config = ((FlatLevelSource)creator
			.getSettings().selectedDimensions().overworld()).settings();
		
		List<FlatLayerInfo> layers =
			List.of(new FlatLayerInfo(1, Blocks.BEDROCK),
				new FlatLayerInfo(2, Blocks.DIRT),
				new FlatLayerInfo(1, Blocks.SMOOTH_STONE));
		
		creator.updateDimensions(
			(drm, dorHolder) -> dorHolder.replaceOverworldGenerator(drm,
				new FlatLevelSource(config.withBiomeAndLayers(layers,
					config.structureOverrides(), config.getBiome()))));
	}
}
